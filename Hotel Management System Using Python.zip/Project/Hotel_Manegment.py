import pickle
import os

HOTEL_FILE = "hotels.dat"
ROOM_FILE = "rooms.dat"
BOOKING_FILE = "bookings.dat"

# ---------------- HOTEL & BRANCH (ADMIN) ----------------

def load_hotels():
    hotels = []
    if os.path.exists(HOTEL_FILE):
        with open(HOTEL_FILE, "rb") as f:
            try:
                while True:
                    hotels.append(pickle.load(f))
            except EOFError:
                pass
    return hotels

def load_rooms():
    rooms = []
    if os.path.exists(ROOM_FILE):
        with open(ROOM_FILE, "rb") as f:
            try:
                while True:
                    rooms.append(pickle.load(f))
            except EOFError:
                pass
    return rooms

def save_hotels(hotels):
    with open(HOTEL_FILE, "wb") as f:
        for h in hotels:
            pickle.dump(h, f)

def save_rooms(rooms):
    with open(ROOM_FILE, "wb") as f:
        for r in rooms:
            pickle.dump(r, f)

def add_hotel():
    hotels = load_hotels()
    name = input("Enter hotel name: ")

    for h in hotels:
        if h["hotel"].lower() == name.lower():
            print("❌ Hotel already exists")
            return

    hotels.append({"hotel": name, "branches": []})
    save_hotels(hotels)
    print("✅ Hotel added")


def manage_branches():
    hotels = load_hotels()
    if not hotels:
        print("❌ No hotels found")
        return

    for h in hotels:
        print("Hotel:", h["hotel"])

    hotel = input("Select hotel: ")

    for h in hotels:
        if h["hotel"].lower() == hotel.lower():
            branch = input("Enter branch name: ")
            location = input("Enter location/city: ")
            h["branches"].append({"branch": branch, "location": location})
            save_hotels(hotels)
            print("✅ Branch added")
            return

    print("❌ Hotel not found")


def add_room():
    hotels = load_hotels()
    if not hotels:
        print("❌ No hotel & branch is registered")
        return

    hotel = input("Hotel name: ")

    for h in hotels:
        if h["hotel"].lower() == hotel.lower():
            if not h["branches"]:
                print("❌ No branches found")
                return

            for b in h["branches"]:
                print(b)

            branch = input("Branch name: ")

            for b in h["branches"]:
                if b["branch"].lower() == branch.lower():
                    room_no = int(input("Room number: "))

                    rooms = load_rooms()
                    for r in rooms:
                        if (r["hotel"].lower() == hotel.lower() and
                            r["branch"].lower() == branch.lower() and
                            r["room_no"] == room_no):
                            print("❌ Room already exists in this branch")
                            return

                    room = {
                        "hotel": hotel,
                        "branch": branch,
                        "location": b["location"],
                        "room_no": room_no,
                        "type": input("Type (AC/Non-AC): "),
                        "price": float(input("Price per day: ")),
                        "status": "Available"
                    }

                    with open(ROOM_FILE, "ab") as f:
                        pickle.dump(room, f)

                    print("✅ Room added")
                    return

    print("❌ Invalid hotel or branch")

def display_all_hotels_with_rooms():
    hotels = load_hotels()
    rooms = load_rooms()

    if not hotels:
        print("❌ No hotels found")
        return

    for h in hotels:
        print("\n🏨 Hotel:", h["hotel"])

        if not h["branches"]:
            print("   ❌ No branches")
            continue

        for b in h["branches"]:
            print(f"   📍 Branch: {b['branch']} ({b['location']})")

            found = False
            for r in rooms:
                if (r["hotel"].lower() == h["hotel"].lower() and r["branch"].lower() == b["branch"].lower()):

                    print(f"      🛏 Room {r['room_no']} | {r['type']} | ₹{r['price']} | {r['status']}")
                    found = True

            if not found:
                print("      ❌ No rooms in this branch")


def edit_hotel():
    hotels = load_hotels()
    rooms = load_rooms()

    if not hotels:
        print("❌ No hotels found")
        return

    old = input("Enter hotel name to edit: ")

    for h in hotels:
        if h["hotel"].lower() == old.lower():
            new = input("Enter new hotel name: ")
            h["hotel"] = new

            for r in rooms:
                if r["hotel"].lower() == old.lower():
                    r["hotel"] = new

            save_hotels(hotels)
            save_rooms(rooms)
            print("✅ Hotel updated everywhere")
            return

    print("❌ Hotel not found")

def edit_branch():
    hotels = load_hotels()
    rooms = load_rooms()

    if not hotels:
        print("❌ No hotels found")
        return

    hotel = input("Enter hotel name: ")

    for h in hotels:
        if h["hotel"].lower() == hotel.lower():
            if not h["branches"]:
                print("❌ No branches found")
                return

            for b in h["branches"]:
                print(b)

            old_branch = input("Enter branch name to edit: ")

            for b in h["branches"]:
                if b["branch"].lower() == old_branch.lower():
                    new_branch = input("Enter new branch name: ")
                    new_location = input("Enter new location/city: ")

                    for r in rooms:
                        if (r["hotel"].lower() == hotel.lower() and
                            r["branch"].lower() == old_branch.lower()):
                            r["branch"] = new_branch
                            r["location"] = new_location

                    b["branch"] = new_branch
                    b["location"] = new_location

                    save_hotels(hotels)
                    save_rooms(rooms)
                    print("✅ Branch updated everywhere")
                    return

    print("❌ Hotel not found")

def edit_room():
    rooms = load_rooms()
    if not rooms:
        print("❌ No rooms found")
        return

    print("\n📋 AVAILABLE HOTELS & ROOMS")
    display_all_hotels_with_rooms()

        

    hotel = input("Hotel name: ")
    branch = input("Branch name: ")
    room_no = int(input("Room number to edit: "))

    for r in rooms:
        if (r["hotel"].lower() == hotel.lower() and
            r["branch"].lower() == branch.lower() and
            r["room_no"] == room_no):

            print("Current details:", r)

            r["type"] = input("New Type (AC/Non-AC): ")
            r["price"] = float(input("New price per day: "))
            r["status"] = input("Status (Available/Booked): ")

            save_rooms(rooms)
            print("✅ Room updated successfully")
            return

    print("❌ Room not found")

def remove_hotel():
    hotels = load_hotels()
    rooms = load_rooms()

    if not hotels:
        print("❌ No hotels found")
        return

    name = input("Enter hotel name to remove: ")

    for h in hotels:
        if h["hotel"].lower() == name.lower():
            hotels.remove(h)
            save_hotels(hotels)

            rooms = [r for r in rooms if r["hotel"].lower() != name.lower()]
            save_rooms(rooms)

            print("✅ Hotel and all its rooms removed successfully")
            return

    print("❌ Hotel not found")

def view_all_bookings():
    if not os.path.exists(BOOKING_FILE):
        print("❌ No bookings found")
        return

    print("\n--- ALL BOOKINGS ---")
    found = False

    with open(BOOKING_FILE, "rb") as f:
        try:
            while True:
                b = pickle.load(f)
                print("--------------------------------")
                print("Customer:", b["customer"]["name"])
                print("Phone:", b["customer"]["phone"])
                print("Hotel:", b["hotel"])
                print("Branch:", b["branch"])
                print("Room No:", b["room_no"])
                print("Days:", b["days"])
                print("Total Amount: ₹", b["total"])
                found = True
        except EOFError:
            pass

    if not found:
        print("❌ No bookings available")

# ---------------- USER FUNCTIONS ----------------

def view_hotels_by_location(location):
    hotels = load_hotels()
    found = False

    print("\n--- Hotels in", location, "---")
    for h in hotels:
        for b in h["branches"]:
            if b["location"].lower() == location.lower():
                print("Hotel:", h["hotel"], "| Branch:", b["branch"])
                found = True

    if not found:
        print("❌ No hotels found")


def view_rooms(location):
    if not os.path.exists(ROOM_FILE):
        print("❌ No rooms available")
        return []

    available = []
    print("\n--- Available Rooms ---")
    with open(ROOM_FILE, "rb") as f:
        try:
            while True:
                r = pickle.load(f)
                if r["location"].lower() == location.lower() and r["status"] == "Available":
                    print(r)
                    available.append(r)
        except EOFError:
            pass

    if not available:
        print("❌ No rooms available")

    return available


def book_room(room, days, customer):
    rooms = []

    with open(ROOM_FILE, "rb") as f:
        try:
            while True:
                rooms.append(pickle.load(f))
        except EOFError:
            pass

    for r in rooms:
        if (r["hotel"] == room["hotel"] and
            r["branch"] == room["branch"] and
            r["room_no"] == room["room_no"]):

            r["status"] = "Booked"
            total = r["price"] * days

            booking = {
                "customer": customer,
                "hotel": r["hotel"],
                "branch": r["branch"],
                "location": r["location"],
                "room_no": r["room_no"],
                "days": days,
                "total": total
            }

            with open(BOOKING_FILE, "ab") as bf:
                pickle.dump(booking, bf)

            print("\n✅ ROOM BOOKED SUCCESSFULLY")
            print("Hotel:", r["hotel"])
            print("Branch:", r["branch"])
            print("Room No:", r["room_no"])
            print("Total Amount:", total)

            break

    with open(ROOM_FILE, "wb") as f:
        for r in rooms:
            pickle.dump(r, f)


def user_flow():
    location = input("Enter location/city: ")

    view_hotels_by_location(location)
    rooms = view_rooms(location)

    if not rooms:
        return

    choice = input("\nDo you want to book a room? (Y/N): ").lower()
    if choice != 'y':
        print("👍 Booking cancelled")
        return

    print("\n--- Enter Customer Details ---")
    customer = {
        "name": input("Name: "),
        "phone": input("Phone: "),
        "id_proof": input("ID proof: ")
    }

    room_no = int(input("Enter room number to book: "))
    days = int(input("Number of days: "))

    for r in rooms:
        if r["room_no"] == room_no:
            book_room(r, days, customer)
            return

    print("❌ Invalid room number")

def search_booking_by_customer():
    if not os.path.exists(BOOKING_FILE):
        print("❌ No bookings found")
        return

    name = input("Enter customer name to search: ").lower()
    found = False

    with open(BOOKING_FILE, "rb") as f:
        try:
            while True:
                b = pickle.load(f)
                if b["customer"]["name"].lower() == name:
                    print("--------------------------------")
                    print("Customer:", b["customer"]["name"])
                    print("Phone:", b["customer"]["phone"])
                    print("Hotel:", b["hotel"])
                    print("Branch:", b["branch"])
                    print("Room No:", b["room_no"])
                    print("Days:", b["days"])
                    print("Total Amount: ₹", b["total"])
                    found = True
        except EOFError:
            pass

    if not found:
        print("❌ No booking found for this customer")

# ---------------- EDIT -----------------
def edit_details():
    while True:
        print("1. Edit Hotel name")
        print("2. Edit Branch and Location details")
        print("3. Edit Room details")

        ch = int(input("Choice: "))

        if ch==1:
            edit_hotel()
            break
        elif ch==2:
            edit_branch()
            break
        elif ch==3:
            edit_room()
            break

def cancel_booking():
    if not os.path.exists(BOOKING_FILE):
        print("❌ No bookings found")
        return

    bookings = []
    with open(BOOKING_FILE, "rb") as f:
        try:
            while True:
                bookings.append(pickle.load(f))
        except EOFError:
            pass

    if not bookings:
        print("❌ No bookings to cancel")
        return

    print("\n--- BOOKINGS ---")
    for b in bookings:
        print("--------------------------------")
        print("Customer:", b["customer"]["name"])
        print("Hotel:", b["hotel"])
        print("Branch:", b["branch"])
        print("Room No:", b["room_no"])
        print("Days:", b["days"])
        print("Total:", b["total"])

    hotel = input("\nEnter hotel name: ")
    branch = input("Enter branch name: ")
    room_no = int(input("Enter room number: "))

    updated_bookings = []
    cancelled = None

    for b in bookings:
        if (b["hotel"].lower() == hotel.lower() and
            b["branch"].lower() == branch.lower() and
            b["room_no"] == room_no and
            cancelled is None):
            cancelled = b
        else:
            updated_bookings.append(b)

    if cancelled is None:
        print("❌ Booking not found")
        return

    # Update room status back to Available
    rooms = load_rooms()
    for r in rooms:
        if (r["hotel"].lower() == hotel.lower() and
            r["branch"].lower() == branch.lower() and
            r["room_no"] == room_no):
            r["status"] = "Available"

    save_rooms(rooms)

    # Save updated bookings
    with open(BOOKING_FILE, "wb") as f:
        for b in updated_bookings:
            pickle.dump(b, f)

    print("✅ Booking cancelled successfully")

# ---------------- MENUS ----------------

def admin_menu():
    while True:
        print("\n--- ADMIN MENU ---")
        print("1. Add Hotel")
        print("2. Add Branch")
        print("3. Add Room")
        print("4. Edit Details of Hotel")
        print("5. Remove Hotel")
        print("6. View All Bookings")
        print("7. Exit")

        ch = int(input("Choice: "))

        if ch == 1:
            add_hotel()
        elif ch == 2:
            manage_branches()
        elif ch == 3:
            add_room()
        elif ch == 4:
            edit_details()
        elif ch == 5:
            remove_hotel()
        elif ch == 6:
            view_all_bookings()
        elif ch == 7:
            break

def user_menu():
    while True:
        print("\n--- USER MENU ---")
        print("1. Search & Book Hotel")
        print("2. Cancel Booking")
        print("3. Search Booking by Customer Name")
        print("4. Exit")

        ch = int(input("Choice: "))

        if ch == 1:
            user_flow()
        elif ch == 2:
            cancel_booking()
        elif ch == 3:
            search_booking_by_customer()
        elif ch == 4:
            break

# ---------------- MAIN ----------------

while True:
    print("\n=== HOTEL MANAGEMENT SYSTEM ===")
    print("1. Admin")
    print("2. User")
    print("3. Exit")

    ch = int(input("Choice: "))

    if ch == 1:
        admin_menu()
    elif ch == 2:
        user_menu()
    elif ch == 3:
        print("Thank you for using the system!")
        break
